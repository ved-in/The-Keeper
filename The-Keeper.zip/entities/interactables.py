import pygame
import core.view as view
import ui.dialogue as dialogue
import entities.animations as animations

from typing import Optional, Callable


class Interactable:    
    def __init__(self, name, world_x, y, w, h, lines_by_day, color=(140, 130, 120), anim_path=None, anim_scale=1.0):
        self.name = name
        self.world_x = world_x
        self.y = y
        self.w = w
        self.h = h
        self.lines_by_day = lines_by_day  # { day: ["line1", ...] }
        self.color = color
        self.used_today = False
        self.hovered = False
        self.on_use: Optional[Callable[[], None]] = None # F__K PYLANCEEE
        
        self.anim_key = None
        if anim_path:
            self.anim_key = f"interactable_{name.lower().replace(' ', '_')}"
            animations.register(self.anim_key, "idle", anim_path, scale=anim_scale)
    
    def reset_daily(self):
        self.used_today = False
        
    def screen_rect(self, world_offset):
        cx = self.world_x + world_offset
        return view.rect(cx - self.w / 2, self.y - self.h / 2, self.w, self.h)
    
    def is_on_screen(self, world_offset):
        rect = self.screen_rect(world_offset)
        screen_rect = view.content_rect()
        return rect.colliderect(screen_rect)
    
    def handle_click(self, pos, world_offset, day):
        if not self.is_on_screen(world_offset):
            return False
        if self.screen_rect(world_offset).collidepoint(pos):
            if hasattr(self, "on_use") and self.on_use:
                self.on_use()
                return True
            lines = self.lines_by_day.get(day, self.lines_by_day.get("default", ["..."]))
            dialogue.show(lines, style="thought", reveal_speed=40, default_speaker="player")
            self.used_today = True
            return True
        return False
    
    def update(self, mouse_pos, world_offset):
        self.hovered = self.screen_rect(world_offset).collidepoint(mouse_pos)
        
    def draw(self, screen, world_offset, font=None):
        rect = self.screen_rect(world_offset)
        if self.anim_key:
            frame = animations.get_frame(self.anim_key, "idle")
            if frame:
                # center the sprite on the rect center
                screen.blit(frame, (rect.centerx - frame.get_width() // 2, rect.centery - frame.get_height() // 2))
        else:
            color = tuple(max(0, c - 40) for c in self.color) if self.used_today else self.color
            pygame.draw.rect(screen, color, rect, border_radius=3)
        if self.hovered and font:
            label = font.render(self.name, True, (240, 235, 210))
            screen.blit(label, (rect.centerx - label.get_width() // 2, rect.top - label.get_height() - 6))
